const express = require("express");
const app = express();
const path = require("path");
const bodyparser=require("body-parser");

const  mysql = require("mysql");
const con=mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    datbase:"bankingsystem",
})
con.connect((err)=>{
    if(err)throw err;
    console.log("connection created!!");
})
app.use(express.static(__dirname+"/public"));
app.set("set-engine","hbs");
app.set("views",path.join(__dirname,"views"));
app.get("/",(req,res)=>{
    res.render("bank.hbs");
})
app.get("/create",(req,res)=>{
    res.render("createuser.hbs");
})
app.get("/transfermoney",(req,res)=>{
    res.render("transfermoney.hbs");
})
app.get("/transactionhistory",(req,res)=>{
    res.render("transactionhistory.hbs");
})
app.get("/login",(req,res)=>{
    res.render("login.hbs");
})

app.get("/create",(req,res)=>{
    const{name,email,age,aadhar,pan,balance} = req.query;
    let qry= "select * from user where email=? or aadhar=?";
    mysql.query(qry,[email,aadhar],(err,results)=>{
        if(err)
        throw err;
        else{
            if(results.length>0){
                res.redirect("createuser.hbs",{checkmsg:true})
            } else {
               let qry2="insert into user values(?,?,?,?,?,?)";
               mysql.query(qry2,[name,email,age,aadhar,pan,balance],(err,results)=>{
                if(results.affectedRows>0){
                    res.redirect("createuser.hbs",{mesg:true})
                }
               })
            }
        }

    })
})


app.listen(8000,()=>{
    console.log("Port Running at 8000");
})